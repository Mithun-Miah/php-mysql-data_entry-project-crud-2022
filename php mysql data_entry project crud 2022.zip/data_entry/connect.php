<?php

// Database Connection with mysql database
$host = "localhost";
$user_name = "root";
$password = "";
$dbname = "data_entry";
$connect = mysqli_connect($host, $user_name, $password, $dbname);

// Database Connection Process Check
if($connect){
    echo "Database Connection Success";
} else{
    echo "Database Connection Fail";
}


?>